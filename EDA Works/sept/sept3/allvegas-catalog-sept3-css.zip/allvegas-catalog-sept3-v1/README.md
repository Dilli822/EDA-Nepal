

---file locations----

--- for style.css
-- -- C:\inetpub\wwwroot\NexGen\Test\Sales\Jaunt2\Content\assets\jaunt2\css---
******* style.css*********


***************for catalog.css***********
-- C:\inetpub\wwwroot\NexGen\Test\Sales\Jaunt2\Content\assets\jaunt2\css
**** catalog.css*****





!!!! for openToWeb\style.css!!!!!!!!!!
=========openToWeb===================
C:\inetpub\wwwroot\NexGen\Test\Sales\Jaunt2\Content\assets\openToWeb
*********style.css*****************
=====================================


*******for AdminLTE.customize.css*******
C:\inetpub\wwwroot\NexGen\Test\Sales\Jaunt2\Content\dist\css
_****** AdminLTE.customize.css********
