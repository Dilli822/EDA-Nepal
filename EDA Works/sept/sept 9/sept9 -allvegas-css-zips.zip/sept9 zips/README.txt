
1.Index.cshtml
-- C:\inetpub\wwwroot\NexGen\Test\Admin\Destin DIY\Areas\Jaunt2\Views\Hotel

2. style.css
C:\inetpub\wwwroot\NexGen\Test\Admin\Destin DIY\Content\assets\jaunt2\css
----- style.css-----

3. _LayoutJaunt2.cshtml
--C:\inetpub\wwwroot\NexGen\Test\Admin\Destin DIY\Views\Shared

4.GroupInfo.cshtml
-- C:\inetpub\wwwroot\NexGen\Test\Admin\Destin DIY\Areas\Jaunt2\Views\Trip

5. DIYParticipantList.cshtml
--C:\inetpub\wwwroot\NexGen\Test\Admin\Destin DIY\Areas\Jaunt2\Views\Participant

