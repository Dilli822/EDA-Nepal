
1. standard css is jaunt/css/style.css
--C:\inetpub\wwwroot\NexGen\Test\Admin\Destin DIY\Content\assets\jaunt2\css

2. _LandingJaunt2.cshtml and _LayoutJaunt2.cshtml is
-- C:\inetpub\wwwroot\NexGen\Test\Admin\Destin DIY\Views\Shared
