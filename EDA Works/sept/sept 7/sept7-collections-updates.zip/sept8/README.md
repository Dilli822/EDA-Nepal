

1. jaunt2/css/style.css
- C:\inetpub\wwwroot\NexGen\Test\Admin\Destin DIY\Content\assets\jaunt2\css
------ style.css--------------------

2. Participant.css
---C:\inetpub\wwwroot\NexGen\Test\Admin\Destin DIY\Content\assets\Pages\jaunt2
---- Participant.css


3. _LayoutJaunt2.cshtml
---C:\inetpub\wwwroot\NexGen\Test\Admin\Destin DIY\Views\Shared
------------_LayoutJaunt2.cshtml--------------

4. _LandingJaunt2.cshtml
---- -C:\inetpub\wwwroot\NexGen\Test\Admin\Destin DIY\Views\Shared
------------_LandingJaunt2.cshtml--------------

5. for url:https://jaunt2sales.qa.nexgenmtgs.com/dashboard/index/T992872Z8
---Dashboard
---C:\inetpub\wwwroot\NexGen\Test\Sales\Jaunt2\Content\assets\jaunt2\css
------ style.csss-------

6. BookCarService
---C:\inetpub\wwwroot\NexGen\Test\Sales\Jaunt2\Content\assets\BookCarService\css
---- style.css

7.HotelBed
---- C:\inetpub\wwwroot\NexGen\Test\Admin\Destin DIY\Content\assets\HotelBed\css
------------- style.css----------