

*********************************
C:\inetpub\wwwroot\NexGen\Test\Admin\Destin DIY\Content\assets\jaunt2\css
----- style.css----
1. style.css
********************************


*******************************
--- landing page footer bg color---
*Note: HotelBed/css/style.css
2. style.css
C:\inetpub\wwwroot\NexGen\Test\Admin\Destin DIY\Content\assets\HotelBed\css
---- style.css----
********************************

*******Note folder: Sales*********
---- dashboard-- url --link
----- Test\Sales\Jaunt2
3. style.css
---C:\inetpub\wwwroot\NexGen\Test\Sales\Jaunt2\Content\assets\jaunt2\css
--- style.css---