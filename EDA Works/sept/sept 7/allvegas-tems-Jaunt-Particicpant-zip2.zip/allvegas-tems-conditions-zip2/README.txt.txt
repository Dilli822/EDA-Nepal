-----------Files locations----------
1. _LandingJaunt2.cshtml and _LayoutJaunt2.cshtml
C:\inetpub\wwwroot\NexGen\Test\Admin\Destin DIY\Views\Shared

2. Participant.css
C:\inetpub\wwwroot\NexGen\Test\Admin\Destin DIY\Content\assets\Pages\jaunt2

3. style.css
C:\inetpub\wwwroot\NexGen\Test\Admin\Destin DIY\Content\assets\jaunt2\css