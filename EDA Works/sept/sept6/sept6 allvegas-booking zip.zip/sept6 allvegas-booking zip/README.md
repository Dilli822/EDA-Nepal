
-----sept 6 2021 
------allvegas
----- http://jaunt2sales.qa.nexgenmtgs.com/BookCarService/Index

--------Files Location------
1. style.css
---- C:\inetpub\wwwroot\NexGen\Test\Sales\Jaunt2\Content\assets\jaunt2\css--
-------- style.css-----


2. _LayoutBooking.cshtml
---C:\inetpub\wwwroot\NexGen\Test\Sales\Jaunt2\Views\Shared--
------ _LayoutBooking.cshtml-----


3. Index.cshtml
---- C:\inetpub\wwwroot\NexGen\Test\Sales\Jaunt2\Views\Shared---
----------- Index.cshtml------

