
----- Files Locations------
1. for _LayoutCatalog.cshtml
C:\inetpub\wwwroot\NexGen\Test\Sales\Jaunt2\Views\Shared
---- _LayoutCatalog.cshtml-----

2. for standard css
**************C:\inetpub\wwwroot\NexGen\Test\Sales\Jaunt2\Content\assets\jaunt2\css******
-------style.css----------

3.for AdminLTE.customize.css
----- C:\inetpub\wwwroot\NexGen\Test\Sales\Jaunt2\Content\dist\css\--
------ AdminLTE.customize.css-----

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
* Note: for openToWeb folder style.css *
4. ////////////////openToweb css//////////////////
// C:\inetpub\wwwroot\NexGen\Test\Sales\Jaunt2\Content\assets\openToWeb
// style.css

5. 