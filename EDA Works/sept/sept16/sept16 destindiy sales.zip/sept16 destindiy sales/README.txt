
-----this is for AdminDomain Page
1. material-dashboard.css
---C:\inetpub\wwwroot\NexGen\Test\Admin\Destin DIYTest\Content\assets\DIY\Css

-----This is For Sales-- page of destindiy.
2. Views
-- C:\inetpub\wwwroot\NexGen\Test\Sales\DIY\Views