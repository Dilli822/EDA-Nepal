C:\inetpub\wwwroot\NexGen\Test\Sales\Jaunt2\Content\assets\jaunt2\css
---- style.css----