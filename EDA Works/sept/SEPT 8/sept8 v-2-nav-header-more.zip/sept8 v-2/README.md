

1. jaunt2/css/style.css
- C:\inetpub\wwwroot\NexGen\Test\Admin\Destin DIY\Content\assets\jaunt2\css
------ style.css--------------------

2. _LayoutJaunt2.cshtml
---C:\inetpub\wwwroot\NexGen\Test\Admin\Destin DIY\Views\Shared
------------_LayoutJaunt2.cshtml--------------

3. _LandingJaunt2.cshtml
---- -C:\inetpub\wwwroot\NexGen\Test\Admin\Destin DIY\Views\Shared
------------_LandingJaunt2.cshtml--------------

4. sales
-- C:\inetpub\wwwroot\NexGen\Test\Sales\Jaunt2\Content\assets\jaunt2\css
--- style.css
