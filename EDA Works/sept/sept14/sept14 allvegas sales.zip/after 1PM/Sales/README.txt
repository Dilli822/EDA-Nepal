-- File location:
1. Index.cshtml
---C:\inetpub\wwwroot\NexGen\Test\Sales\Jaunt2\Views\Dashboard


2. _LayoutDashboardModern.cshtml
--C:\inetpub\wwwroot\NexGen\Test\Sales\Jaunt2\Views\Shared