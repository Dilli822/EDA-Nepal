
--1.Index.cshtml
--C:\inetpub\wwwroot\NexGen\Test\Admin\Destin DIY\Areas\Jaunt2\Views\Hotel