
--- Files Locations---
1. style.css
--C:\inetpub\wwwroot\NexGen\Test\Admin\Destin DIY\Content\assets\jaunt2\css

2. Finish.cshtml
---C:\inetpub\wwwroot\NexGen\Test\Admin\Destin DIY\Content\assets\Pages\jaunt2

3.DIYIndex.cshtml
--- C:\inetpub\wwwroot\NexGen\Test\Admin\Destin DIY\Areas\Jaunt2\Views\Participant

4. GroupInfo.cshtml
--C:\inetpub\wwwroot\NexGen\Test\Admin\Destin DIY\Areas\Jaunt2\Views\Trip


5. _LayoutJaunt2.cshtml and _LandingJaunt2.cshtml
-- C:\inetpub\wwwroot\NexGen\Test\Admin\Destin DIY\Views\Shared

6. LogOn.cshtml
--C:\inetpub\wwwroot\NexGen\Test\Admin\Destin DIY\Views\UserAuthJaunt2

7. and SignUp.cshtml
-- C:\inetpub\wwwroot\NexGen\Test\Admin\Destin DIY\Views\UserRegisterJaunt2
