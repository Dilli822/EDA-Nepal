
1. Destin DIYTest
-- C:\inetpub\wwwroot\NexGen\Test\Admin\Destin DIYTest

2. DestinSales
--- C:\inetpub\wwwroot\NexGen\Test\Sales\DIY