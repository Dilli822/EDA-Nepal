
1. Sales
--C:\inetpub\wwwroot\NexGen\Test\Sales\Jaunt2\Content\assets\jaunt2\css
-- jaunt2sales.

2. openToWeb
-C:\inetpub\wwwroot\NexGen\Test\Sales\Jaunt2\Content\assets\openToWeb
--- style.css--